package solution;

public class RubberDuck extends Duck implements Unflyable, Squeakable {
	
	@Override
	public void display() {
		System.out.println("  displaying");
		
	}
}
