package solution;
public interface ClosedCurve {	
	double computePerimeter();
}
