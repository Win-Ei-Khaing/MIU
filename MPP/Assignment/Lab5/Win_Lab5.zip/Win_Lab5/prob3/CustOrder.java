package prob3;

public interface CustOrder {
	public Customer getCustomer();
	public Order getOrder();
}
