package prob2;

public abstract class ClosedCurve {
	abstract double computeArea();
}
