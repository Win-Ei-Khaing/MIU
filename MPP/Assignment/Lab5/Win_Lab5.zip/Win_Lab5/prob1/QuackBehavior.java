package prob1;

public interface QuackBehavior {
	void quack();
}
