package lesson10.exercise_2;

@BugReport
public class MoreBadCode {
	public int subtract(int a, int b) {
		return a + b;
	}
}
