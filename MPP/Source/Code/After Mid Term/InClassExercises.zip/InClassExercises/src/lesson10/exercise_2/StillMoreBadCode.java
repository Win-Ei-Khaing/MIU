package lesson10.exercise_2;

@BugReport(assignedTo = "??") //, severity = ?)
public class StillMoreBadCode {

	public int multiply(int x, int y) {
		return x / y;

	}

}
