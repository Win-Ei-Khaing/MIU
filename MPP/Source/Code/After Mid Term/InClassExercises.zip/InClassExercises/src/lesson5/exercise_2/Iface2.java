package lesson5.exercise_2;

public interface Iface2 {
	int myMethod(int x);
}
