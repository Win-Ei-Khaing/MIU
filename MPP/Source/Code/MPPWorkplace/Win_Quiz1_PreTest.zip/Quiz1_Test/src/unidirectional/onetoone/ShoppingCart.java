package unidirectional.onetoone;

public class ShoppingCart {

}
