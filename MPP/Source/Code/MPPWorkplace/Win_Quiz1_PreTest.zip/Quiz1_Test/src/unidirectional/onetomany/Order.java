package unidirectional.onetomany;

public class Order {

}
