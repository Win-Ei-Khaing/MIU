﻿Win Ei Khaing
613403


I answered 
* Prob1 - under prob1 folder
* Prob2 - under prob2 folder
* Prob3 - under prob3 folder
* Prob4 - under prob4 folder
* SCI - under sci folder


Thank you.