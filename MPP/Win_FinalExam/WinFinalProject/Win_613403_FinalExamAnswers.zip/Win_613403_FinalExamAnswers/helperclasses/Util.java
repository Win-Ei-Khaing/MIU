package helperclasses;

public class Util {
	public static final String DATE_PATTERN = "MM/dd/yyyy";
}
