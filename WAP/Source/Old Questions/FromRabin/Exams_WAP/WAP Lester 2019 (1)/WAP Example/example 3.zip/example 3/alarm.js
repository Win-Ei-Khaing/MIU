function minMenu(){

	var select = document.getElementById('sec');
	var min = 59;

	for (i=0; i <= min; i++) {
		select.options[select.options.length] = new Option(i < 10 ? "0" + i : i, i);
	}
}
minMenu();

function secMenu(){

	var select = document.getElementById('sec');
	var sec = 59;

	for (i=0; i <= sec; i++) {
		select.options[select.options.length] = new Option(i < 10 ? "0" + i : i, i);
	}
}
secMenu();
function alarmSet() {
	
	var min = document.getElementById('min');
	
	var sec = document.getElementById('sec');
    
    var selectedMin = min.options[min.selectedIndex].value;
    var selectedSec = sec.options[sec.selectedIndex].value;
    var selectedAP = ap.options[ap.selectedIndex].value;

	document.getElementById('min').disabled = true;
    document.getElementById('sec').disabled = true;
    
    };
