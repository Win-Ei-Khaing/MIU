package com.miu.bookrecycler
data class Book(val name: String, val author: String)