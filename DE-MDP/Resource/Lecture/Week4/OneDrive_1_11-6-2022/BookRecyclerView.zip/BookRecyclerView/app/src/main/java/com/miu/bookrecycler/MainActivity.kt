package com.miu.bookrecycler

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val books = ArrayList<Book>()
        books.add(Book("Java","Horstman"))
        books.add(Book("Kotlin","Joshua Bloch"))
        books.add(Book("JavaFX","Herbert"))
        books.add(Book("Android Essentials","Kathy"))
        books.add(Book("Android Development","Bruce"))
        books.add(Book("Kotlin Coding","Brain Goetz"))
        books.add(Book("Java","Horstman"))
        books.add(Book("Kotlin","Joshua Bloch"))
        books.add(Book("JavaFX","Herbert"))
        books.add(Book("Android Essentials","Kathy"))
        books.add(Book("Android Development","Bruce"))
        books.add(Book("Kotlin Coding","Brain Goetz"))
        books.add(Book("Java","Horstman"))
        books.add(Book("Kotlin","Joshua Bloch"))
        books.add(Book("JavaFX","Herbert"))
        books.add(Book("Android Essentials","Kathy"))
        books.add(Book("Android Development","Bruce"))
        books.add(Book("Kotlin Coding","Brain Goetz"))
        books.add(Book("Java","Horstman"))
        books.add(Book("Kotlin","Joshua Bloch"))
        books.add(Book("JavaFX","Herbert"))
        books.add(Book("Android Essentials","Kathy"))
        books.add(Book("Android Development","Bruce"))
        books.add(Book("Kotlin Coding","Brain Goetz"))
        // Set the Layout Manager
        recyclerView1.layoutManager =LinearLayoutManager(this)
        // Create an object for the MyAdapter
        val adapter = MyAdapter(books)
        // Set adapter to your RecyclerView
        recyclerView1.adapter = adapter
    }
}