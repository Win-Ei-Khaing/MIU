package students;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import students.domain.Address;
import students.domain.Student;
import students.repository.StudentRepository;

import java.util.List;

@SpringBootApplication
public class Application implements CommandLineRunner{

    @Autowired
    StudentRepository studentRepository;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // create student
        Student student = new Student(1000,"Win Ei Khaing", "6418191641", "wkhaing1@miu.edu");
        Address address = new Address("1000N 4th Street", "Fairfield", "52557");
        student.setAddress(address);
        studentRepository.save(student);
        student = new Student(1001,"Win Ei Khaing", "2078191641", "wkhaing2@miu.edu");
        address = new Address("109B Grove St", "Bergenfield", "07621");
        student.setAddress(address);
        studentRepository.save(student);
        student = new Student(1002,"Thae Su", "6018191641", "thaesu@miu.edu");
        address = new Address("260 Union St", "Northvale", "07647");
        student.setAddress(address);
        studentRepository.save(student);

        //get students
        System.out.println("-----------All students ----------------");
        List<Student> results=studentRepository.findAll();
        for (Student s : results)
            System.out.println(s.toString());

        System.out.println("-----------All students with a certain name ----------------");
        results=studentRepository.findByName("Win Ei Khaing");
        for (Student s : results)
            System.out.println(s.toString());

        System.out.println("-----------A student with a certain phoneNumber  ----------------");
        System.out.println(studentRepository.findByPhoneNumber("6418191641").toString());

        System.out.println("-----------All students from a certain city  ----------------");
        results=studentRepository.findStudentWithCity("Northvale");
        for (Student s : results)
            System.out.println(s.toString());
    }
}
