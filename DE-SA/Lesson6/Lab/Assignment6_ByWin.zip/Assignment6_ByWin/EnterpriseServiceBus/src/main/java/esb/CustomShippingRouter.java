package esb;

public class CustomShippingRouter {
    public String route(Order order) {
        if(order.getOrderType().trim().toLowerCase().equals("international"))
            return "internationalshippingchannel";
        else
            return (order.getAmount() > 175) ? "nextdayshippingchannel" : "shippingchannel";
    }
}
