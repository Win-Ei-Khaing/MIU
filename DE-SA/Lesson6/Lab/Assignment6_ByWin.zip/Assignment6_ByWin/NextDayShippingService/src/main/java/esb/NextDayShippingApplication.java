package esb;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class NextDayShippingApplication {

	public static void main(String[] args) {
		SpringApplication.run(NextDayShippingApplication.class, args);
	}

}
