import './App.css';
import Dashboard from './containers/Dashboard/Dashboard';

function App() {
  return (
    <Dashboard/>
  );
}

export default App;
