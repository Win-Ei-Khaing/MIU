import './Student.css';

function Student(props) {
        return (
            <article className="Student" onClick={props.clicked}>
                <h1>Student</h1>
                <div className="Info">
                    <div className="Id">id: {props.id}</div>
                    <div className="Name">Name: {props.name}</div>
                    <div className="Major">Major: {props.major}</div>
                </div>
            </article>
        );
    };

export default Student;