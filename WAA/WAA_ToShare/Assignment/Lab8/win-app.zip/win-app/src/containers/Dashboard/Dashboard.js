import react, {useState} from "react";
import Students from "../Students/Students";
import './Dashboard.css';

function Dashboard(){

    const [student, setStudent] = useState({
        id: "",
        name: "",
        major: ""
    });

    const [newName, setNewName]=useState("Meti");
    const [tempName, setTempName]=useState("");

    const changeFirstName =()=>{setNewName(tempName)};

    return (
        <div className="Dashboard">
            <session className="StudentList">
                <Students newName={newName} clicked={(id, name, major)=>setStudent({id: id, name: name, major: major})}/>
            </session>
            <div className="Input">
                <input type="text" id="inputFirstName" onChange={(evt)=>setTempName(evt.target.value)}></input>
                <br/>
                <button onClick={changeFirstName}>Change Name</button>
            </div>
            <article className="Output">
                <h1>Student</h1>
                <div className="Info">
                    <div className="Id">id: {student.id}</div>
                    <div className="Name">Name: {student.name}</div>
                    <div className="Major">Major: {student.major}</div>
                    <div>
                        <u>edit</u>
                        <u>delete</u>
                    </div>
                </div>
            </article>
        </div>
    );
}

export default Dashboard;