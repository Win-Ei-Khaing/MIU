import react, {useState} from "react";
import Student from "../../components/Student/Student";

function Students(props){
    //console.log(props.newName);

    const[students, setStudents] = useState([
        {id:111, name: "Meti", major: "CS"},
        {id:112, name: "Tedros", major: "CS"},
        {id:113, name: "Pascal", major: "CS"}
    ]);

    const newStudents = [...students];
    newStudents[0] = {...newStudents[0], name: props.newName};
    //console.log(newStudents[0].id+"___"+newStudents[0].name);

    const postSelectedData= (id, name, major) => {
        props.clicked(id, name, major)
    };

    const studentList = newStudents.map(s =>  <Student key={s.id} id={s.id} name={s.name} major={s.major} clicked={()=>postSelectedData(s.id, s.name, s.major)}/>) 

    return studentList;
}

export default Students;