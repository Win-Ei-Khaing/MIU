package miu.edu.demo.repository;

import miu.edu.demo.domain.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserRepository extends CrudRepository<User, Long> {
    public List<User> findAll();

    public User findById(long id);

     @Query(value = "SELECT u.* FROM USER u WHERE (SELECT COUNT(p.*) FROM POST p WHERE p.USER_ID=u.ID)>1", nativeQuery = true)
    public List<User> findUsersWithMoreThanOnePost();
}
