package edu.mum.domain;

public class Test {

    String y;

    public Test() {

    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }
}
