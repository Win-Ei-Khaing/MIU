import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import './FullPost.css';
import { APIConfig } from '../../store/API-Config';


const FullPost = (props) => {

    const APIs = useContext(APIConfig);
    const postAPI = APIs.postAPI;

    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
    }

    const [postCall, setPostCall] = useState({});
    const [renderedId, setRenderedId] = useState(null); // remove this one

    useEffect(() => {
        setRenderedId(props.match.params.id);
    }, []);

    useEffect(() => {
        if (renderedId !== props.match.params.id) {
            axios(postAPI + props.match.params.id, { headers })
                .then(response => {
                    setPostCall(response.data);
                    setRenderedId(props.match.params.id);
                    console.log('This wont get called again ');
                })
        }

    }, [props]);  // if I leave this empty here, it will update twice.  

    const deletePost = () => {
        axios.delete(postAPI + props.match.params.id, { headers })
            .then(response => {
                props.history.push('/');
                console.log(response);
            })
            .catch(error => console.log(error.message))
    };

    // const printOut = () => {
    //     alert("This is the URL =>  " + props.match.url)
    //     alert("This is the PATH =>  " + props.match.path)
    // }

    let post = <p style={{ justifyContent: 'space-around' }}> Please select a Post!</p>;

    if (props.match.params.id != null) {
        post = (
            <div className="FullPost">
                <h1>{postCall.title}</h1>
                <p>{postCall.content}</p>
                <div className="Edit">
                    <button onClick={deletePost} className="Delete">Delete</button>

                    {/* If you want to compare between props.match.url and props.match.path => Uncomment the button below and uncomment the printout function */}
                    {/* <button onClick={printOut} className="Delete">Compare props.match</button> */}
                </div>
            </div>
        );
    }


    return post;
}

export default FullPost;