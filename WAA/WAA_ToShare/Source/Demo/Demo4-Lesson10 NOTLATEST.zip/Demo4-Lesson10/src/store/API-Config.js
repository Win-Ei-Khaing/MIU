import React from 'react';

export const APIConfig = React.createContext([]);
