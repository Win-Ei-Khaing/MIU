import React from 'react';

export const Test = React.memo((props) => {

    console.log('RENDER FROM TEST');
    
    return <button onClick={props.increment}> Increment from Test </button>  
});