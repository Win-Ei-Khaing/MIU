import React, { useContext, useEffect, useMemo, useState, useCallback, useReducer, useRef } from 'react';
import axios from 'axios';
import Post from '../../components/Post/Post';
import './Posts.css';
import { Link, Route } from 'react-router-dom';
import FullPost from '../../components/FullPost/FullPost';
import { APIConfig } from '../../store/API-Config';
import { Test } from './Test';


const Posts = (props) => {

    const APIs = useContext(APIConfig);
    const postAPI = APIs.postAPI;
    const textField = useRef();
    const [posts, setPosts] = useState([]);
    const [isLoading, setLoading] = useState(false); // indicates that is retreiving data
    const [error, setError] = useState();
    const [show, setVisibility] = useState(false);  // Just for demonstration 

    //==These states are just for explanation=========
    const [value, setValue] = useState(0);  // click button , sends textInput
    const [count, setCount] = useState(0);
    //================================================

    //=================useReducer Example ============
    const initialState = { count: 0 };

    function reducer(state, action) {
        switch (action.type) {
            case 'increment':
                return { count: state.count + 1 };
            case 'decrement':
                return { count: state.count - 1 };
            default:
                throw new Error();
        }
    }

    function Counter() {
        const [state, dispatch] = useReducer(reducer, initialState);
        return (
            <React.Fragment>
                Count: {state.count}
                <button onClick={() => dispatch({ type: 'decrement' })}>-</button>
                <button onClick={() => dispatch({ type: 'increment' })}>+</button>
            </React.Fragment>
        );
    }
    //=================useReducer Example ============


    const [incrementValue, setIncrementValue] = useState(1);

    function fetchPostsHandler() {
        const headers = {
            'Access-Control-Allow-Origin': '*',
        }
        setLoading(true);
        setError(null); // this is to set the error to null, if there were any previous errors existing 
        //console.log(isLoading);
        axios(postAPI, { headers })
            .then(response => {
                setPosts(response.data);
                setLoading(false);
            })
            .catch(error => {
                setError(error.message);

            })

    }

    useEffect(fetchPostsHandler, []); // This will be fetched when mounted

    // JUST FOR EXPLNATION useMemo()=========================

    const expensiveComputation = (num) => {
        console.log('Computation done!  ' + num * 10);
        return num * 10;
    };
    const memoizedValue = useMemo( ()=> expensiveComputation(value), [value]);
    // const memoizedValue = expensiveComputation(value); // Uncomment this and then click on the Hide/Show button to see how the value is loading everytime it is re-rendered

    const memoizedFunction = (num) => {
        setValue(num);
        console.log("MEMOIZED VALUE:" + memoizedValue);
    }
   
    // JUST FOR EXPLNATION  useCallback()====================

    // const plainIncrement = () => {
    //     setCount(c => c + incrementValue); //1
    // }

    const useCallbackIncrement = useCallback(() => {
        setCount(c => c + incrementValue);
    }, [incrementValue]);
    //=======================================================

    const rposts = posts.map(post => {
        return <Link to={props.match.url + '/' + post.id} key={post.id}>
            <Post
                title={post.title}
                author={post.author}
                id={post.id} />
        </Link>
    });

    let content = <p >No posts available</p>;
    if (isLoading) {
        content = <p> Loading ... </p>;  // MAKE THIS WAIT FOR 2 minutes
    }
    else if (rposts.length > 0) {
        content = rposts;
    }
    else if (error) {
        content = <p>{error}</p>;
    }

    return (
        <div>
            <section className="Posts">
                {content}
            </section>
            <Route path={props.match.path + '/:id'} component={FullPost} />
            <div style={{ display: 'flex', justifyContent: 'center', textAlign: 'center' }}>

                <section>
                    {show && <label> SECRET TEXT</label>}
                    {/* {show ?<label> SECRET TEXT</label> : null} */}
                    <button onClick={() => setVisibility(!show)}> Hide/Show</button>
                </section>

                <section>
                    <input type="number" ref={textField}/>
                    {/*  */}
                    <button onClick={() => memoizedFunction(textField.current.value)}> Compute</button>
                </section>


                <section>
                    <button onClick={() => {
                        setIncrementValue(incrementValue + 5);
                        console.log(incrementValue);
                    }} > Add 5 </button>

                    <div>useCallback Value Count: {count}</div>
                    <Test increment={useCallbackIncrement} />
                    {/* plainIncrement */}
                </section>

            </div>
            <section>
                This is the useReducer Value: {Counter()}
            </section>
        </div>

    );
}

export default Posts;
