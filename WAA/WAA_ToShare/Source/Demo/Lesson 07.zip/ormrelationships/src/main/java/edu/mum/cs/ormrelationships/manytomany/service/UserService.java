package edu.mum.cs.ormrelationships.manytomany.service;

import edu.mum.cs.ormrelationships.manytomany.domain.User;

//Code completed for this interface
public interface UserService {
	User save(User user);
}
