package edu.mum.cs.ormrelationships;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrmrelationshipsApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrmrelationshipsApplication.class, args);
    }

}
