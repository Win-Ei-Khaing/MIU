package com.example.demoSep21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSep21Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoSep21Application.class, args);
	}
}
