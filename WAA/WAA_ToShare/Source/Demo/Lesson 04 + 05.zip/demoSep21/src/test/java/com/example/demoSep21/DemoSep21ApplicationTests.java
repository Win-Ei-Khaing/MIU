package com.example.demoSep21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSep21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
