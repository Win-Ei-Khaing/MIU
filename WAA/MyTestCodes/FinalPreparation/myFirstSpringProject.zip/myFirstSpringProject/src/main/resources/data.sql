

INSERT into POST (id, title, content, author) VALUES (1,'Apple','Apple is a fruit','John');
INSERT into POST (id, title, content, author) VALUES (2, 'Carrot','Carrot is a vegetable','Ted');
INSERT into POST (id, title, content, author) VALUES (3, 'Pizza','Pizza is a fastfood','Shiva');
INSERT into POST (id, title, content, author) VALUES (4, 'Coke','Coke is a softdrink','Carl');
