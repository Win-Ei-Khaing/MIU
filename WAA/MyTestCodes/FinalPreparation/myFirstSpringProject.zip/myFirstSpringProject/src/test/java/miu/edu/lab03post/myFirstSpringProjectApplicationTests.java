package miu.edu.lab03post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class myFirstSpringProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
