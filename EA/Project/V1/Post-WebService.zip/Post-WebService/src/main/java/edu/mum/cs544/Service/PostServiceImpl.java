package edu.mum.cs544.Service;

import edu.mum.cs544.Domain.Post;
import edu.mum.cs544.Repository.PostRepository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PostServiceImpl implements PostService{
    @Autowired
    PostRepository postRepository;

    @Override
    public List<Post> findAll() {
        return postRepository.findAllAlivePosts();
    }

    @Override
    public Post findById(long id) {
        return postRepository.findById(id);
    }

    @Override
    public List<Post> findByTitle(String title){
        return postRepository.findByTitle(title);
    }

    @Override
    public void add(Post post) {
       post.setStatus(true); //as only deletion will set it true
       post.setPostedDate(LocalDateTime.now()); //set the current time

       postRepository.save(post);
    }

    @Override
    public void update(Post post) {
       post.setStatus(true); //as only deletion will set it true
       post.setPostedDate(LocalDateTime.now());

       postRepository.save(post);
        
    }

    @Override
    public void delete(long id) {
        //as we change only status flag from ture to false at deletion
        Post postToDelete = findById(id);
        postToDelete.setStatus(false);

        postRepository.save(postToDelete);
    }

    
}
