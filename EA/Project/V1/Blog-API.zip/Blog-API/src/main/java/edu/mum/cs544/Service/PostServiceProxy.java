package edu.mum.cs544.Service;

import java.net.URI;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import edu.mum.cs544.Domain.Post;

@Service
public class PostServiceProxy implements PostService{
    @Autowired
    private RestTemplate restTemplate;
    private final String postUrl = "http://localhost:8080/posts/{id}"; 
    private final String postsUrl = "http://localhost:8080/posts/";
    private final String postsByTitleUrl="http://localhost:8080/postsByTitle?title=";

    @Override
    public List<Post> findAll() {
        ResponseEntity<List<Post>> response = restTemplate.exchange(postsUrl, HttpMethod.GET, null, new ParameterizedTypeReference<List<Post>>(){});
       return response.getBody();
    }

    @Override
    public Post findById(long id) {
        return restTemplate.getForObject(postUrl, Post.class, id);
    }

    @Override
    public List<Post> findByTitle(String title) {
       ResponseEntity<List<Post>> response = restTemplate.exchange(postsByTitleUrl+title, HttpMethod.GET, null, new ParameterizedTypeReference<List<Post>>(){});
       return response.getBody();
    }
    
    @Override
    public Long add(Post post) {
        URI uri = restTemplate.postForLocation(postsUrl, post);
        if (uri == null) { return null; }
        Matcher m = Pattern.compile(".*/posts/(\\d+)").matcher(uri.getPath()); 
        m.matches();
        return Long.parseLong(m.group(1));
    }

    @Override
    public void update(long id, Post post) {
        restTemplate.put(postUrl, post, id);
    }

    @Override
    public void delete(long id) {
        restTemplate.delete(postUrl, id);
    }

    
}
