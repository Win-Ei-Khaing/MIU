package edu.mum.cs544.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import edu.mum.cs544.Domain.Post;
import edu.mum.cs544.Service.PostService;

@RestController
@RequestMapping("/blog")
public class BlogRestController {
    @Autowired
    PostService postService;

    @GetMapping(value="/posts")
    public List<Post> getAll() {
        return postService.findAll();
    }
       
    @GetMapping(value= "/posts/{id}")
    public Post getById(@PathVariable int id) {
        return postService.findById(id);
    }

    @GetMapping(value= "/postsByTitle")
    public List<Post> getByTitle(@RequestParam String title) {
        return postService.findByTitle(title);
    }
    
    @PostMapping(value="/posts")
    public Long add(@RequestBody Post post) {
        return postService.add(post);
    }

    @PutMapping(value= "/posts/{id}")
    public void  update(@PathVariable int id, @RequestBody Post post) {
       postService.update(id, post);
    }

    @DeleteMapping(value="/posts/{id}")
    public void delete(@PathVariable int id) {
        postService.delete(id);
    }
}
