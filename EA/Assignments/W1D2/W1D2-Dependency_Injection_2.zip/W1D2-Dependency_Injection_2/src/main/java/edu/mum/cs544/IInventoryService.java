package edu.mum.cs544;

public interface IInventoryService {
    public int getNumberInStock(int productNumber);
}
