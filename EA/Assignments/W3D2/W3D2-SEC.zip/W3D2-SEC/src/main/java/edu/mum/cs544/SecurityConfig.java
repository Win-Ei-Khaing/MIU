package edu.mum.cs544;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
    //  @Autowired
    //  private DataSource dataSource;

    //  @Bean
    //  public PasswordEncoder passwordEncoder() {
    //      return new BCryptPasswordEncoder();
    //  }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception { 
        //Part A and B
          auth.inMemoryAuthentication() 
          .withUser("admin").password("{noop}123").roles("USER","ADMIN").and() 
          .withUser("user").password("{noop}bla").roles("USER");

        //Part C - with default schema
        //but it gave me this error ->"You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'varchar_ignorecase(50) not null primary key,password varchar_ignorecase(500) not' at line 1" 
        // auth.jdbcAuthentication().dataSource(dataSource)
        // .withDefaultSchema();

        //so, I created required tables and insert some text data manually with the same data in slides
        //  auth.jdbcAuthentication()
        //       .dataSource(dataSource)
        //       .usersByUsernameQuery("select username,password, enabled from users where username=?") 
        //       .authoritiesByUsernameQuery("select u.username, a.authority "+
        //       " from users u, authorities a "+
        //       " where u.username = a.username and u.username = ?");
    }
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //Part A and B
        // http
        //     .authorizeRequests().antMatchers("/sec/**").hasRole("USER").and() 
        //     .formLogin().permitAll().and()
        //     .logout();

        //Part C
        http
            .authorizeRequests().antMatchers("/sec/**").hasRole("USER").and() 
            //as login page is in index.jsp
            .formLogin().loginPage("/").loginProcessingUrl("/login") .usernameParameter("username").passwordParameter("password") .failureUrl("/")
            .defaultSuccessUrl("/cars")
            .permitAll().and()
            .logout().logoutUrl("/").logoutSuccessUrl("/login") .invalidateHttpSession(true).deleteCookies("cookie-names");
    }
}
