INSERT INTO Book(id, title, ISBN, author, price) VALUES(NULL, 'Summer', 'ISBN1', 'Leyla', 200.00);
INSERT INTO Book(id, title, ISBN, author, price) VALUES(NULL, 'Winter', 'ISBN2', 'Welda', 300.00);