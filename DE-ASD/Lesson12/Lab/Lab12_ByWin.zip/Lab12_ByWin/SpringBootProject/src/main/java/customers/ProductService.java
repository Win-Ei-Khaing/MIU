package customers;

import org.springframework.stereotype.Service;

@Service
public class ProductService{

	public void addProduct() {
		System.out.println("add product");
	}
}
