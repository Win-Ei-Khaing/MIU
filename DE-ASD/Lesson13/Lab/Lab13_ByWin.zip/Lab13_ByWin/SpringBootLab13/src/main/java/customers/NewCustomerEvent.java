package customers;

public class NewCustomerEvent {
    private Customer customer;

    public NewCustomerEvent(Customer customer) {
        this.customer = customer;
    }
    public String getMessage() {
        return customer.toString();
    }
}
