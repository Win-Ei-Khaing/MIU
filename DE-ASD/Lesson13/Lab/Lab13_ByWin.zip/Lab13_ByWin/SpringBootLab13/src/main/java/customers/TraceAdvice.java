package customers;

import java.time.LocalDateTime;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StopWatch;

@Aspect
@Configuration
public class TraceAdvice {
    // Part a: AOP

    @After("execution(* customers.EmailSender.sendEmail(..)) && args(email,message)")
    public void tracemethod(JoinPoint joinpoint, String email, String message) {
        EmailSender emailSender = (EmailSender)joinpoint.getTarget();
        System.out.println(LocalDateTime.now()+" method="+joinpoint.getSignature().getName()
        +" address="+email+" message= "+message+ " outgoing mail server= "+emailSender.getOutgoingMailServer());
    }

    @Around("execution(* customers.CustomerDAO.*(..))")
    public Object invoke(ProceedingJoinPoint call ) throws Throwable {

        StopWatch sw = new StopWatch();
        sw.start(call.getSignature().getName());
        Object retVal = call.proceed();
        sw.stop();
        long totaltime = sw.getLastTaskTimeMillis();
        // print the time to the console
        System.out.println(call.getSignature().getName()+" took "+totaltime+ "ms");
        return retVal;
    }
}