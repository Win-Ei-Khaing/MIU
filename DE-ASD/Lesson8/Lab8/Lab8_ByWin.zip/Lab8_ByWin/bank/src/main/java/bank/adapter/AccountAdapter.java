package bank.adapter;

import bank.domain.Account;
import bank.dto.AccountDTO;

public class AccountAdapter {
    private static AccountAdapter instance;

    public static AccountAdapter getInstance() {
        return (instance == null) ? instance = new AccountAdapter() : instance;
    }

    public AccountDTO convertToDTO(Account account) {
        return new AccountDTO(account.getAccountnumber(), account.getEntryList(), account.getCustomer(), account.getBalance());
    }
}
