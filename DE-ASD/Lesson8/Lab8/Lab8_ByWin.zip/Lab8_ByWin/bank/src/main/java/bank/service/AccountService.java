package bank.service;

import java.lang.reflect.Proxy;
import java.util.Collection;
import java.util.stream.Collectors;

import bank.adapter.AccountAdapter;
import bank.dao.AccountDAO;
import bank.dao.IAccountDAO;
import bank.domain.Account;
import bank.domain.Customer;
import bank.dto.AccountDTO;
import bank.proxy.LoggingProxy;
import bank.proxy.TimingProxy;


public class AccountService implements IAccountService {
private IAccountDAO timingProxy;
	
	public AccountService(){
		IAccountDAO accountDAO = new AccountDAO();
        ClassLoader classLoader = AccountDAO.class.getClassLoader();
        IAccountDAO loggingProxy = (IAccountDAO) Proxy.newProxyInstance(classLoader, new Class[]{IAccountDAO.class}, new LoggingProxy(accountDAO));
        timingProxy = (IAccountDAO) Proxy.newProxyInstance(classLoader, new Class[]{IAccountDAO.class}, new TimingProxy(loggingProxy));
    }

	public AccountDTO createAccount(long accountNumber, String customerName) {
		Account account = new Account(accountNumber);
		Customer customer = new Customer(customerName);
		account.setCustomer(customer);
		timingProxy.saveAccount(account);
		return AccountAdapter.getInstance().convertToDTO(account);
	}

	public void deposit(long accountNumber, double amount) {
		Account account = timingProxy.loadAccount(accountNumber);
		account.deposit(amount);
		timingProxy.updateAccount(account);
	}

	public AccountDTO getAccount(long accountNumber) {
		Account account = timingProxy.loadAccount(accountNumber);
		return AccountAdapter.getInstance().convertToDTO(account);
	}

	public Collection<AccountDTO> getAllAccounts() {
		return timingProxy.getAccounts()
                .stream()
                .map(account -> AccountAdapter.getInstance().convertToDTO(account))
                .collect(Collectors.toList());
	}

	public void withdraw(long accountNumber, double amount) {
		Account account = timingProxy.loadAccount(accountNumber);
		account.withdraw(amount);
		timingProxy.updateAccount(account);
	}

	public void transferFunds(long fromAccountNumber, long toAccountNumber, double amount, String description) {
		Account fromAccount = timingProxy.loadAccount(fromAccountNumber);
		Account toAccount = timingProxy.loadAccount(toAccountNumber);
		fromAccount.transferFunds(toAccount, amount, description);
		timingProxy.updateAccount(fromAccount);
		timingProxy.updateAccount(toAccount);
	}
}
