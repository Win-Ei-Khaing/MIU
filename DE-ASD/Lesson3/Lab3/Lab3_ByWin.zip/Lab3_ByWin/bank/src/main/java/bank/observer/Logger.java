package bank.observer;

import bank.domain.Account;

public class Logger implements Observer{

    private void log(Account account){
        System.out.println("Wrote a log for "+account.getAccountnumber()+" in Logger");
    }

    @Override
    public void process(Account account) {
        log(account);
    }
    
}
