package bank.observer;

import bank.domain.Account;

public interface ObserverForNew {
    void process(Account account);
}
