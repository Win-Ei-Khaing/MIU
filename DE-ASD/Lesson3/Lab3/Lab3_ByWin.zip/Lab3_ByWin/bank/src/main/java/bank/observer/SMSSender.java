package bank.observer;

import bank.domain.Account;

public class SMSSender implements Observer {

    private void sendSMS(Account account){
        System.out.println("Sent SMS to "+account.getAccountnumber()+" from SMSSender");
    }

    @Override
    public void process(Account account) {
        sendSMS(account);
    }
    
}
