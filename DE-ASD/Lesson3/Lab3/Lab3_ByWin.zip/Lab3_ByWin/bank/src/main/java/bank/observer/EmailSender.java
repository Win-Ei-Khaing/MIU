package bank.observer;

import bank.domain.Account;

public class EmailSender implements ObserverForNew {

    private void sendEmail(Account account){
        System.out.println("Sent Email to "+account.getAccountnumber()+" from EmailSender");
    }

    @Override
    public void process(Account account) {
        sendEmail(account);
    }
    
    
}
