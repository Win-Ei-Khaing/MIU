package bank.subject;

import java.util.ArrayList;
import java.util.List;

import bank.domain.Account;
import bank.observer.ObserverForNew;

public class SubjectForNew {
    private List<ObserverForNew> observersForNew = new ArrayList<>();
    
    public void addObserver(ObserverForNew observerForNew){
        observersForNew.add(observerForNew);
    }

    public void removeObserver(ObserverForNew observerForNew){
        observersForNew.remove(observerForNew);
    }

    public void notifyObservers(Account account){
        for (ObserverForNew observerForNew : observersForNew ){
            observerForNew.process(account);
        }
    }
}
