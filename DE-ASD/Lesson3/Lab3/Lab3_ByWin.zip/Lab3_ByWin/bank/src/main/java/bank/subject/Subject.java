package bank.subject;

import java.util.ArrayList;
import java.util.List;

import bank.domain.Account;
import bank.observer.Observer;

public class Subject {
    private List<Observer> observers = new ArrayList<>();
    
    public void addObserver(Observer observer){
        observers.add(observer);
    }

    public void removeObserver(Observer observer){
        observers.remove(observer);
    }

    public void notifyObservers(Account account){
        for (Observer observer : observers ){
            observer.process(account);
        }
    }
}
