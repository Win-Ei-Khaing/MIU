package bank.email;

public interface IEmailSender {
	void send(String message);

}
