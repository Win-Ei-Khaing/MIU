package bank.integration;

import bank.domain.Account;

public interface ISender {
    void send(Account account);
}
