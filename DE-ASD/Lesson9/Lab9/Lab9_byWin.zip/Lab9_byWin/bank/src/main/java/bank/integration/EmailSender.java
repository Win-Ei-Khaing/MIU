package bank.integration;

import bank.domain.Account;

public class EmailSender implements ISender{

    private static EmailSender emailSender;

    private EmailSender() {
        // Prevent form the reflection api.
        if (emailSender != null) {
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }

    public static EmailSender getEmailSender() {
        // Double check locking pattern
        if (emailSender == null) { //Check for the first time
            synchronized (EmailSender.class) { //Check for the second time.
                if (emailSender == null) 
                    emailSender = new EmailSender();
            }
        }
        return emailSender;
    }

    public EmailSender getConnection() {
        return emailSender;
    }
    
    // This method is called immediately after an object of this class is deserialized.
    protected Object readResolve() {
        return getEmailSender();
    }
    
    @Override
    public void send(Account account) {
        System.out.println("Sending email to :"+account.getCustomer().getName() + " from production email sender");
    }
}
