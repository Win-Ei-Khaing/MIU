package bank.factory;

import bank.dao.AccountDAO;
import bank.dao.IAccountDAO;
import bank.decorator.AccountDAOLogger;
import bank.integration.EmailSender;
import bank.integration.ISender;

public class ProductionFactory implements MyFactory{
    @Override
    public IAccountDAO getAccountDAO() {
        AccountDAO accountDao=new AccountDAO();
        System.out.println(accountDao.getAccounts().size());
        return new AccountDAOLogger(accountDao);
    }

    @Override
    public ISender getEmailSender() {
        return EmailSender.getEmailSender();
    }
}