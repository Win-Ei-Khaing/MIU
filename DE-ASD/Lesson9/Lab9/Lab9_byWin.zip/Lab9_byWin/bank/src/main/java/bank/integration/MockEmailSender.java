package bank.integration;

import bank.domain.Account;

public class MockEmailSender implements ISender{
    @Override
    public void send(Account account) {
        System.out.println("Sending email to :"+account.getCustomer().getName() + " from mock email sender");
    }
}
