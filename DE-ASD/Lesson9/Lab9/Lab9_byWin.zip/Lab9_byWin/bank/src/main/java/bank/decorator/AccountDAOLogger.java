package bank.decorator;

import java.util.Collection;

import bank.dao.IAccountDAO;
import bank.domain.Account;

public class AccountDAOLogger extends AccountDAODecorator{

    public AccountDAOLogger(IAccountDAO component) {
       this.component=component;
    }

    @Override
    public void saveAccount(Account account) {
        System.out.println("Saving Log : Account dao logger");
        component.saveAccount(account);
    }

    @Override
    public void updateAccount(Account account) {
        System.out.println("Update Log : Account dao logger");
        component.updateAccount(account);
    }

    @Override
    public Account loadAccount(long accountnumber) {
        System.out.println("Loading account Log : Account dao logger ");
        return component.loadAccount(accountnumber);
    }

    @Override
    public Collection<Account> getAccounts() {
        System.out.println("Getting accounts Log : Account dao logger ");
        return component.getAccounts();
    }
    
}
