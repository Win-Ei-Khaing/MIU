package bank.factory;

import bank.dao.IAccountDAO;
import bank.integration.ISender;

public interface MyFactory {
    public IAccountDAO getAccountDAO();
    public ISender getEmailSender();
}
