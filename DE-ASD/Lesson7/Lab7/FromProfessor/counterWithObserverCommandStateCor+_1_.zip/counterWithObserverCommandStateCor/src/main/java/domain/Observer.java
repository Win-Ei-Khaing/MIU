package domain;

public interface Observer {
	public void update(int countervalue);
}
