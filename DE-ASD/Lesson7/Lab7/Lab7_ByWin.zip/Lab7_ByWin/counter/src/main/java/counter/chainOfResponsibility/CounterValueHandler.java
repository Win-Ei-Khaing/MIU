package counter.chainOfResponsibility;

public abstract class CounterValueHandler {
    public CounterValueHandler nextHandler;

    public CounterValueHandler(CounterValueHandler nextHandler) {
        this.nextHandler = nextHandler;
    }
    
    public CounterValueHandler getNextHandler() {
        return nextHandler;
    }

    public abstract void handle(int count);
}
