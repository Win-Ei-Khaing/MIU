package counter.chainOfResponsibility;

public class OrangeHandler extends CounterValueHandler {

    public OrangeHandler(CounterValueHandler nextHandler) {
        super(nextHandler);
    }

    @Override
    public void handle(int count) {
        if (count % 2 != 0 && count >= 15 && count != 17 && count != 19) {
            System.out.println("Orange");
        }
    }
}
