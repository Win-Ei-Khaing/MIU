package counter;

import counter.chainOfResponsibility.CounterValueHandler;

public class Counter extends Subject{
	private CounterState counterState;
	private int count=0;
	private CounterValueHandler counterValueHandler;

	public Counter(CounterValueHandler counterValueHandler){
		super();
		this.counterValueHandler=counterValueHandler;
		counterState=new SingleDigit(this);
	}

	public void setState(CounterState state){
		counterState=state;
	}
	
	public void increment(){
		count=counterState.increment();
		donotify(count);
		counterValueHandler.handle(count);
		log();
	}
	
	public void decrement(){
		count=counterState.decrement();
    	donotify(count);
		counterValueHandler.handle(count);
		log();
	}

	public int getCount(){
		return count;
	}

	private void log(){
		System.out.println("Count : "+count);
	}
}
