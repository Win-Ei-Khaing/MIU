package Handlers;

import Models.CarmeraRecord;

public class MoreThanOneUnpaidTicketHandler extends RecordHandler {

    public MoreThanOneUnpaidTicketHandler(RecordHandler nextHandler) {
        super(nextHandler);
    }

    @Override
    public void handle(CarmeraRecord record) {
        if(record.getCar().getOwner().getNumberOfTickets()>=1)
            System.out.println("Owner has one or more unpaid tickets. Notify Police.");
        else
            System.out.println("This car is not Stolen. Not Speeding. Registered. Owner has no one or more unpaid Tickets.");
    }
}
