package Handlers;
import Models.CarmeraRecord;

public class UnregisteredHandler extends RecordHandler{
    public UnregisteredHandler(RecordHandler nextHandler) {
        super(nextHandler);
    }

    @Override
    public void handle(CarmeraRecord record) {
        if(!record.getCar().getRegistered()) 
            System.out.println("This car is currently not registered. Send the owner a ticket.");
        else
            nextHandler.handle(record);
    }
}
