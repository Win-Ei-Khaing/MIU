package Handlers;

import Models.CarmeraRecord;

public class SpeedingHandler extends RecordHandler {
    public SpeedingHandler(RecordHandler nextHandler) {
        super(nextHandler);
    }

    @Override
    public void handle(CarmeraRecord record) {
        if(record.getSpeed()>100)
            System.out.println("This car is speeding. Send the owner a speeding ticket.");
        else
            nextHandler.handle(record);
    }
}
