package Handlers;
import Models.CarmeraRecord;

public class StolenHandler extends RecordHandler {
    public StolenHandler(RecordHandler nextHandler) {
        super(nextHandler);
    }

    @Override
    public void handle(CarmeraRecord record) {
        if(record.getCar().getStolen())
            System.out.println("This is a stolen car. Notify Police.");
        else
            nextHandler.handle(record);
    }
}
