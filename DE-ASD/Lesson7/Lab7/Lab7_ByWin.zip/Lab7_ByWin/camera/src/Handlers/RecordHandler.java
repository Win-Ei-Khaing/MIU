package Handlers;

import Models.CarmeraRecord;

public abstract class RecordHandler {
    protected RecordHandler nextHandler;
    public RecordHandler(RecordHandler nextHandler) {
    this.nextHandler = nextHandler;
    }
    public RecordHandler getNextHandler() {
    return nextHandler;
    }
    public abstract void handle(CarmeraRecord record);
}
