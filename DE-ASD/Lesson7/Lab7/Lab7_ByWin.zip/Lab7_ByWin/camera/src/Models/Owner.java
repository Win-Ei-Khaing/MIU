package Models;

public class Owner {
    private int id;
    private String name;
    private int numberOfUnpaidTickets;
    public Owner(int id, String name, int numberOfUnpaidTickets) {
        this.id = id;
        this.name = name;
        this.numberOfUnpaidTickets = numberOfUnpaidTickets;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getNumberOfTickets() {
        return numberOfUnpaidTickets;
    }
    public void setNumberOfTickets(int numberOfUnpaidTickets) {
        this.numberOfUnpaidTickets = numberOfUnpaidTickets;
    } 
}
