package Models;
public class CarmeraRecord {
    private int id;
    private Car car;
    private int speed;
    private int cameraId;
    public CarmeraRecord(int id, Car car, int speed, int cameraId) {
        this.id=id;
        this.car = car;
        this.speed = speed;
        this.cameraId = cameraId;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public Car getCar() {
        return car;
    }
    public void setCar(Car car) {
        this.car = car;
    }
    public int getSpeed() {
        return speed;
    }
    public void setSpeed(int speed) {
        this.speed = speed;
    }
    public int getCameraId() {
        return cameraId;
    }
    public void setCameraId(int cameraId) {
        this.cameraId = cameraId;
    }
}
