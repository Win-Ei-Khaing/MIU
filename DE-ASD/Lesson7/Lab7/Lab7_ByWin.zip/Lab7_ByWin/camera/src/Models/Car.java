package Models;

public class Car {
    private int id;
    private String licensePlate;
    private Boolean stolen;
    private Boolean registered;
    private Owner owner;

    public Car(int id, String licensePlate, Boolean stolen, Boolean registered, Owner owner) {
        this.id = id;
        this.licensePlate = licensePlate;
        this.stolen = stolen;
        this.registered = registered;
        this.owner = owner;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getLicensePlate() {
        return licensePlate;
    }
    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }
    public Boolean getStolen() {
        return stolen;
    }
    public void setStolen(Boolean stolen) {
        this.stolen = stolen;
    }
    public Boolean getRegistered() {
        return registered;
    }
    public void setRegistered(Boolean registered) {
        this.registered = registered;
    }
    public Owner getOwner() {
        return owner;
    }
    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    
}
