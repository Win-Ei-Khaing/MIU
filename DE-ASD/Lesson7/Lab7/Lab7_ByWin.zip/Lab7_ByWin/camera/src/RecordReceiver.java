import Handlers.RecordHandler;
import Models.CarmeraRecord;
public class RecordReceiver {
    private RecordHandler handler;

    public void setHandler(RecordHandler handler) {
        this.handler = handler;
    }

    public void handle(CarmeraRecord record){
        handler.handle(record);
    }
}
