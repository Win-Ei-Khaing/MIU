import Handlers.MoreThanOneUnpaidTicketHandler;
import Handlers.SpeedingHandler;
import Handlers.StolenHandler;
import Handlers.UnregisteredHandler;
import Models.Car;
import Models.CarmeraRecord;
import Models.Owner;

public class App {
    public static void main(String[] args) throws Exception {
        Owner owner1=new Owner(1, "Win", 0);
        Owner owner2=new Owner(2, "Ei", 0);
        Owner owner3=new Owner(3, "Khaing", 1);

        Car car1=new Car(11111, "A11111", true, true, owner1);
        Car car2=new Car(11112, "B11112", false, false, owner2);
        Car car3=new Car(11113, "C11113", false, true, owner3);
        Car car4=new Car(11114, "D11114", false, true, owner1);

        CarmeraRecord carmeraRecord1=new CarmeraRecord(1, car1, 75, 1);
        CarmeraRecord carmeraRecord2=new CarmeraRecord(2, car2, 110, 2);
        CarmeraRecord carmeraRecord3=new CarmeraRecord(3, car2, 75, 2);
        CarmeraRecord carmeraRecord4=new CarmeraRecord(4, car3, 90, 3);
        CarmeraRecord carmeraRecord5=new CarmeraRecord(5, car4, 100, 4);

        MoreThanOneUnpaidTicketHandler moreThanOneUnpaidTicketHandler=new MoreThanOneUnpaidTicketHandler(null);
        UnregisteredHandler unregisteredHandler=new UnregisteredHandler(moreThanOneUnpaidTicketHandler);
        SpeedingHandler speedingHandler=new SpeedingHandler(unregisteredHandler);
        StolenHandler stolenHandler=new StolenHandler(speedingHandler);

        RecordReceiver receiver=new RecordReceiver();
        receiver.setHandler(stolenHandler);

        receiver.handle(carmeraRecord1);
        receiver.handle(carmeraRecord2);
        receiver.handle(carmeraRecord3);
        receiver.handle(carmeraRecord4);
        receiver.handle(carmeraRecord5);
    }
}
