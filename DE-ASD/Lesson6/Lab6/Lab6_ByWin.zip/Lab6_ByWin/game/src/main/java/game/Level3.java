package game;

public class Level3 extends LevelState{
    public Level3(Game game) {
        super(game);
    }

    @Override
    public int addPoints(int newPoints) {
        int totalPoints = game.getTotalPoints() + 3*newPoints;
        return totalPoints;
    }

    @Override
    public String getGameLevel() {
        return "3";
    }
}
