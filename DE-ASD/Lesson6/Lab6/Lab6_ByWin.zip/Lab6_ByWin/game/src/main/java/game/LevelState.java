package game;

public abstract class LevelState {
    protected final Game game;

	public LevelState(Game game) {
		this.game = game;
	}

    public abstract int addPoints(int newPoints);
    public abstract String getGameLevel();
}
