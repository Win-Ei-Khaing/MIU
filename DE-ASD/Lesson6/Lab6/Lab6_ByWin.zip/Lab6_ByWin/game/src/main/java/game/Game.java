package game;

import java.util.Random;

public class Game {
	private LevelState levelState;
	private int totalPoints = 0;

	public void setState(LevelState state) {
		this.levelState = state;
	}

	public void play() {
		Random random = new Random();
		totalPoints = levelState.addPoints(random.nextInt(7));
		System.out.println("points="+totalPoints+" level="+levelState.getGameLevel());
	}

	public int getTotalPoints(){
		return totalPoints;
	}
}
