package game;

public class Level2_5 extends LevelState{
    public Level2_5(Game game) {
        super(game);
    }

    @Override
    public int addPoints(int newPoints) {
        int totalPoints = game.getTotalPoints() + newPoints;
        if (totalPoints > 20) { 
            LevelState level3=new Level3(game);
            game.setState(level3);
            totalPoints = totalPoints + 1;
        }
    return totalPoints;
    }

    @Override
    public String getGameLevel() {
        return "2_5";
    }
}
