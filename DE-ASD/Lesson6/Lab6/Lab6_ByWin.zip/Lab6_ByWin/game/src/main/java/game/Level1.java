package game;

public class Level1 extends LevelState{

    public Level1(Game game) {
        super(game);
    }

    @Override
    public int addPoints(int newPoints) {
        int totalPoints = game.getTotalPoints() + newPoints;
			if (totalPoints > 10) { 
				LevelState level2=new Level2(game);
                game.setState(level2);
				totalPoints = totalPoints + 1;
			}
        return totalPoints;
    }

    @Override
    public String getGameLevel() {
        return "1";
    }
    
}
