package counter;

public abstract class CounterState {
    protected final Counter counter;

	public CounterState(Counter counter) {
		this.counter = counter;
	}

    public abstract int increment();
    public abstract int decrement();
    //public abstract String getCounterState();
}
