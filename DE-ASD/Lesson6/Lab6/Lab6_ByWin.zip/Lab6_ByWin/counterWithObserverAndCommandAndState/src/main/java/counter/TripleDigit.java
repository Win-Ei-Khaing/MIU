package counter;

public class TripleDigit extends CounterState{
    public TripleDigit(Counter counter) {
        super(counter);
    }

    @Override
    public int increment() {
        int currentCount=counter.getCount();
        currentCount=currentCount+3;
        return currentCount;
    }

    @Override
    public int decrement() {
        int currentCount=counter.getCount();
        currentCount=currentCount-3;
        return currentCount;
    }

    // @Override
    // public String getCounterState() {
    //     return "Triple Digit";
    // }
}
