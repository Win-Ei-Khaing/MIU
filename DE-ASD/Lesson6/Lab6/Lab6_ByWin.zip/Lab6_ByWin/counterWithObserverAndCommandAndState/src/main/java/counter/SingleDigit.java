package counter;

public class SingleDigit extends CounterState{

    public SingleDigit(Counter counter) {
        super(counter);
    }

    @Override
    public int increment() {
        int currentCount=counter.getCount();
        currentCount++;
        if(Integer.toString(currentCount).length()==2)
            counter.setState(new DoubleDigit(counter));
        return currentCount;
    }

    @Override
    public int decrement() {
        int currentCount=counter.getCount();
        currentCount--;
        if(Integer.toString(currentCount).length()==2)
            counter.setState(new DoubleDigit(counter));
        return currentCount;
    }

    // @Override
    // public String getCounterState() {
    //     return "Single Digit";
    // }
    
}
