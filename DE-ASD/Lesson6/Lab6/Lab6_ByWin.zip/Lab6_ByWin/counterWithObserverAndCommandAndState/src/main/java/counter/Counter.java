package counter;

public class Counter extends Subject{
	private CounterState counterState;
	private int count=0;

	public Counter(){
		counterState=new SingleDigit(this);
	}

	public void setState(CounterState state){
		counterState=state;
	}
	
	public void increment(){
		count=counterState.increment();
		System.out.println("Count : "+count+", Digit : "+Integer.toString(count).length() +", State : "+counterState.getClass().getSimpleName());
    	donotify(count);
	}
	
	public void decrement(){
		count=counterState.decrement();
    	donotify(count);
	}

	public int getCount(){
		return count;
	}
}
