package counter;

public class DoubleDigit extends CounterState{

    public DoubleDigit(Counter counter) {
        super(counter);
    }

    @Override
    public int increment() {
        int currentCount=counter.getCount();
        currentCount=currentCount+2;
        if(Integer.toString(currentCount).length()==3)
            counter.setState(new TripleDigit(counter));
        return currentCount;
    }

    @Override
    public int decrement() {
        int currentCount=counter.getCount();
        currentCount=currentCount-2;
        if(Integer.toString(currentCount).length()==3)
            counter.setState(new TripleDigit(counter));
        return currentCount;
    }

    // @Override
    // public String getCounterState() {
    //     return "Double Digit";
    // }
    
}
