package productcatalog;

public class Application {

	public static void main(String[] args) {
		Category mainCategory=new Category("Lunch Meal");

		Category category1 = new Category("Burmese Food");
	    Category category2 = new Category("US Food");

	    Product product1 = new Product("Mont Hnin Khar");
	    Product product2 = new Product("Nan Gyi Thote");
	    Product product3 = new Product("Pizza");

		mainCategory.addCategory(category1);
		mainCategory.addCategory(category2);
		
	    category1.addCategory(product1);
		category1.addCategory(product2);
		category2.addCategory(product3);

	    mainCategory.print();
	  }

}
