package customers;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class AgeIterator implements Iterator<Customer> {

    private final List<Customer> sortedCustomerList;
    private int position;

    public AgeIterator(List<Customer> customerList){
        this.sortedCustomerList=customerList.stream()
        .sorted(Comparator.comparingInt(Customer::getAge))
        .collect(Collectors.toList());
        this.position=0;
    }

    @Override
    public boolean hasNext() {
        return position<sortedCustomerList.size();
    }

    @Override
    public Customer next() {
        return sortedCustomerList.get(position++);
    }
    
    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
