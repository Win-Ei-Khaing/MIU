package customers;

import java.util.Iterator;
import java.util.List;

public class OddIterator implements Iterator<Customer> {

    private final List<Customer> customerList;
    private int position;

    public OddIterator(List<Customer> customerList){
        this.customerList=customerList;
        this.position=0;
    }

    @Override
    public boolean hasNext() {
        return position<customerList.size();
    }

    @Override
    public Customer next() {
        Customer customer=customerList.get(position);
        position=position+2;
        return customer;
    }
    
    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
