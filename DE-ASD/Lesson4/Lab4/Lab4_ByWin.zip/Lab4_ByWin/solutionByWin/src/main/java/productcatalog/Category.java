package productcatalog;

import java.util.ArrayList;
import java.util.Collection;

public class Category extends ProductCatalog {
	protected Collection<ProductCatalog> productCatalogs = new ArrayList<ProductCatalog>();

	public Category(String name) {
		super(name);
	}

	public void addCategory(ProductCatalog component) {
		productCatalogs.add(component);
	}

	public void print() {
		System.out.println("Category " + name);
		for (ProductCatalog component : productCatalogs) {
			component.print();
		}
	}
}
