package bank.domain;

import java.util.Date;

public class CheckingAccount extends Account {

    public CheckingAccount(long accountnr) {
        super(accountnr);
    }

    @Override
    public double calculateInterest() {
        double interest = 0;
        double balance = getBalance();
        if (balance < 1000)
            interest = balance * 0.015;
        else
            interest = balance * 0.025;
        return interest;
    }

    @Override
    public void addInterest() {
        AccountEntry ae = new AccountEntry(new Date(), calculateInterest(), "interest", "", "");
        entryList.add(ae);
    }

}
