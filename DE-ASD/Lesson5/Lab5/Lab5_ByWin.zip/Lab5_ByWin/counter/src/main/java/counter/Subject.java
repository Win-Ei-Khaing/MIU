package counter;

import java.util.ArrayList;
import java.util.Collection;

public class Subject {
    private Collection<Observer> observerList=new ArrayList<Observer>();

    public void addObserver(Observer observer){
        observerList.add(observer);
    }

    public void doNotify(int countervalue){
        for (Observer observer : observerList) {
            observer.update(countervalue);
        }
    }
}
