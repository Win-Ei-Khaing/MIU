package bank;

import java.util.Collection;

import bank.domain.Account;
import bank.domain.AccountEntry;
import bank.domain.Customer;
import bank.service.AccountService;

public class Application {
	public static void main(String[] args) {
		AccountService accountService = new AccountService();
		// create 2 accounts;
		accountService.createAccount(1111111, "Frank Brown");
		accountService.createAccount(2222222, "John Doe");

		//add command to history list
		HistoryList hlist = new HistoryList();

		//deposit 200 to 1111111
		DepositCommand depositCommand1=new DepositCommand(accountService, 1111111L, 200.00);
		depositCommand1.execute();
		hlist.addCommand(depositCommand1);
		
		//deposit 300 to 1111111
		DepositCommand depositCommand2=new DepositCommand(accountService, 1111111L, 300.00);
		depositCommand2.execute();
		hlist.addCommand(depositCommand2);

		//deposit 50 to 1111111
		DepositCommand depositCommand3=new DepositCommand(accountService, 1111111L, 50.00);
		depositCommand3.execute();
		hlist.addCommand(depositCommand3);

		showBalance(accountService);

		//undo
		hlist.undo();
		System.out.println("\n\nAfter Undo,");
		showBalance(accountService);

		hlist.redo();
		System.out.println("\n\nAfter Redo,");
		showBalance(accountService);

		WithdrawCommand withdrawCommand1=new WithdrawCommand(accountService, 1111111L, 100.00);
		withdrawCommand1.execute();
		hlist.addCommand(withdrawCommand1);

		System.out.println("\n\nWithdraw,");
		showBalance(accountService);

		//use account 2;
		DepositCommand depositCommand4=new DepositCommand(accountService, 2222222, 1000.00);
		depositCommand4.execute();
		hlist.addCommand(depositCommand4);

		System.out.println("\n\nDeposit,");
		showBalance(accountService);

		TransferCommand transferCommand=new TransferCommand(accountService, 2222222, 1111111, 200, "payment for lunch");
		transferCommand.execute();
		hlist.addCommand(transferCommand);

		System.out.println("\n\nTransfer,");
		showBalance(accountService);

		//undo
		hlist.undo();
		System.out.println("\n\nAfter Undo,");
		showBalance(accountService);

		hlist.redo();
		System.out.println("\n\nAfter Redo,");
		showBalance(accountService);
	}

	public static void showBalance(AccountService accountService){
		// show balances
		Collection<Account> accountlist = accountService.getAllAccounts();
		Customer customer = null;
		for (Account account : accountlist) {
			customer = account.getCustomer();
			System.out.println("Statement for Account: " + account.getAccountnumber());
			System.out.println("Account Holder: " + customer.getName());
			System.out.println("-Date-------------------------"
							+ "-Description------------------"
							+ "-Amount-------------");
			for (AccountEntry entry : account.getEntryList()) {
				System.out.printf("%30s%30s%20.2f\n", entry.getDate()
						.toString(), entry.getDescription(), entry.getAmount());
			}
			System.out.println("----------------------------------------"
					+ "----------------------------------------");
			System.out.printf("%30s%30s%20.2f\n\n", "", "Current Balance:",
					account.getBalance());
		}
	}

}


