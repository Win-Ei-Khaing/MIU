package bank;

import bank.service.AccountService;

public class WithdrawCommand implements Command{
    AccountService accountService;
    long accountNumber;
    double amount;
    
    public WithdrawCommand(AccountService accountService, long accountNumber, double amount) {
        this.accountService = accountService;
        this.accountNumber = accountNumber;
        this.amount = amount;
    }

    @Override
    public void execute() {
       accountService.withdraw(accountNumber, amount);
    }

    @Override
    public void unExecute() {
        accountService.deposit(accountNumber, amount);
    }
    
}
