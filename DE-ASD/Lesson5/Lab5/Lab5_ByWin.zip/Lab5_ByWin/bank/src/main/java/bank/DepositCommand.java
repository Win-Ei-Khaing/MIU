package bank;

import bank.service.AccountService;

public class DepositCommand implements Command{
    AccountService accountService;
    long accountNumber;
    double amount;

    
    public DepositCommand(AccountService accountService, long accountNumber, double amount) {
        this.accountService = accountService;
        this.accountNumber = accountNumber;
        this.amount = amount;
    }

    @Override
    public void execute() {
        accountService.deposit(accountNumber, amount);
    }

    @Override
    public void unExecute() {
        accountService.withdraw(accountNumber, amount);
    }
    
}
