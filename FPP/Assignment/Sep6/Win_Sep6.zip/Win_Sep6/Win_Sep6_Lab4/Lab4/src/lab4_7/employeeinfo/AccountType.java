package lab4_7.employeeinfo;

public enum AccountType {
	CHECKING, SAVINGS, RETIREMENT
}
