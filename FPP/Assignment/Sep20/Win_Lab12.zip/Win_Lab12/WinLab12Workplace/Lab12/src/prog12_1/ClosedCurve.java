package prog12_1;

abstract public class ClosedCurve {
	abstract double computeArea();

}
