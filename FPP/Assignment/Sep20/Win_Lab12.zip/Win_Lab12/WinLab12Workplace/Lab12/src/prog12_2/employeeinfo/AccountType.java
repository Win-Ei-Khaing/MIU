package prog12_2.employeeinfo;

public enum AccountType {
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}
