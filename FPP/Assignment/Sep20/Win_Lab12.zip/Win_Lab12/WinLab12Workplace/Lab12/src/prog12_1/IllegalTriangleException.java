package prog12_1;

public class IllegalTriangleException extends IllegalClosedCurveException{

	public IllegalTriangleException() {
		super();
	}

	public IllegalTriangleException(String message) {
		super(message);
	}

	public IllegalTriangleException(Throwable cause) {
		super(cause);
	}
}
