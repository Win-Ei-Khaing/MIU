package prog7_3;

public class BinarySearch {

	public static void main(String[] args) {
		System.out.println(search("abcde",'b'));
		System.out.println(search("abcdefghijklmnopqrs",'i'));
		System.out.println(search("turvwxyz",'i'));
	}

	public static Boolean search(String s, char c) {
		if(s==null || s=="") return false;
		int midIndex=s.length()/2;
		char ch=s.charAt(midIndex);
		if(ch==c) return true;
		if(c<ch) return search(s.substring(0,midIndex), c);
		if(c>ch) return search(s.substring(midIndex+1), c);
		return false;
	}
}
